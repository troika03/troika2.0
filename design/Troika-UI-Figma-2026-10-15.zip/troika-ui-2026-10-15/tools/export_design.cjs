const fs = require('fs');
const path = require('path');
const { chromium } = require(process.env.TROIKA_NODE_MODULES
  ? path.join(process.env.TROIKA_NODE_MODULES, 'playwright')
  : 'C:/Users/kiqu/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');
const ROOT = path.resolve(__dirname, '..');
const requested = process.argv.includes('--update') ? new Set(process.argv[process.argv.indexOf('--update')+1].split(',')) : null;
const F = 'http://www.w3.org/2000/svg';
const escape = text => String(text).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&apos;'}[c]));
const round = n => Math.round(n * 100) / 100;
const titles = {
  home:'Главная',text:'Разговор',tasks:'Дела',files:'Файлы',profile:'Профиль',development:'Разработка',
  project:'Рабочий проект',voice:'Голос',memory:'Память',devices:'Устройства',capabilities:'Возможности',
  appearance:'Интерфейс',advanced:'Дополнительно',api:'Личный API',diagnostics:'Диагностика',history:'История',
  onboarding:'Первое знакомство',permissions:'Разрешения',login:'Вход',register:'Регистрация',
  'new-task':'Новое дело','file-detail':'Документ','create-file':'Создать файл','new-project':'Новый проект',
  'development-detail':'Ход проекта','edit-memory':'Изменить память',subscription:'Тариф и ресурс',usage:'Расход ресурса',
  'device-detail':'Разрешения устройства',privacy:'Приватность',export:'Экспорт данных',approval:'Подтверждение',
  budget:'Оценка задачи',offline:'Нет подключения',help:'Помощь',support:'Обратная связь',compact:'Компактное окно',
  listening:'Слушаю',speaking:'Отвечаю',thinking:'Разбираюсь',acting:'Выполняю',done:'Готово',error:'Ошибка',idle:'Ожидание'
};
const order = ['onboarding','permissions','login','register','home','text','history','tasks','new-task','project',
  'files','file-detail','create-file','development','new-project','budget','development-detail','capabilities',
  'memory','edit-memory','profile','subscription','usage','voice','devices','device-detail','appearance','privacy',
  'export','advanced','api','diagnostics','help','support','approval','offline'];

function contourSvg(size, state='idle', unique='orb') {
  const color = state==='error' ? '228,130,118' : '245,166,35';
  const phase = 1.1, breath = .62, scale = .93 + breath * .08;
  const c = size/2, radius=size*.34*scale;
  const amplitude = ({listening:8,speaking:10,thinking:3,acting:5})[state] || 2+breath*2;
  const points=[];
  for(let n=0;n<=96;n++){
    const a=n/96*Math.PI*2;
    const r=radius+Math.sin(a*3+phase)*amplitude+Math.cos(a*2-phase*.7)*amplitude*.45;
    points.push(`${n?'L':'M'}${round(c+Math.cos(a)*r)} ${round(c+Math.sin(a)*r)}`);
  }
  const signal = ['listening','speaking'].includes(state)
    ? Array.from({length:5},(_,n)=>{const h=12+(Math.sin(phase*2+n*.9)+1)/2*28;return `<rect x="${c-18+n*8}" y="${round(c-h/2)}" width="4" height="${round(h)}" rx="2" fill="#FFF8E7"/>`;}).join('')
    : '';
  let arc='';
  if(['thinking','acting'].includes(state)){
    const r=radius+14,a=phase,b=phase+Math.PI*.72;
    arc=`<path d="M${round(c+Math.cos(a)*r)} ${round(c+Math.sin(a)*r)} A${round(r)} ${round(r)} 0 0 1 ${round(c+Math.cos(b)*r)} ${round(c+Math.sin(b)*r)}" fill="none" stroke="rgb(${color})" stroke-opacity=".85" stroke-width="3" stroke-linecap="round"/>`;
  }
  return `<svg xmlns="${F}" width="${size}" height="${size}" viewBox="0 0 ${size} ${size}"><defs><radialGradient id="${unique}-halo"><stop stop-color="rgb(${color})" stop-opacity=".28"/><stop offset=".48" stop-color="rgb(${color})" stop-opacity=".13"/><stop offset="1" stop-color="rgb(${color})" stop-opacity="0"/></radialGradient><radialGradient id="${unique}-core"><stop stop-color="rgb(${color})" stop-opacity=".96"/><stop offset=".56" stop-color="rgb(${color})" stop-opacity=".54"/><stop offset="1" stop-color="rgb(${color})" stop-opacity="0"/></radialGradient></defs><circle cx="${c}" cy="${c}" r="${size*.52}" fill="url(#${unique}-halo)"/><path d="${points.join(' ')} Z" fill="none" stroke="rgb(${color})" stroke-opacity=".62" stroke-width="${state==='done'?2.2:1.5}"/>${arc}<circle cx="${c}" cy="${c}" r="${size*.25*scale}" fill="url(#${unique}-core)"/>${signal}</svg>`;
}

async function extract(root) {
  const base=root.getBoundingClientRect();
  const nodes=[];
  const measuring=document.createElement('canvas').getContext('2d');
  let serial=0;
  const visible = el => {const s=getComputedStyle(el),r=el.getBoundingClientRect();return s.display!=='none'&&s.visibility!=='hidden'&&Number(s.opacity)!==0&&r.width>0&&r.height>0;};
  const rgba = color => {if(!color||color==='transparent')return null;const n=color.match(/[\d.]+/g);if(!n||n.length<3)return null;return {r:+n[0]/255,g:+n[1]/255,b:+n[2]/255,a:n.length>3?+n[3]:1};};
  const pos = r => ({x:r.x-base.x,y:r.y-base.y,w:r.width,h:r.height});
  function push(node){node.id='layer-'+(++serial);nodes.push(node);}
  function svgSource(el){
    const clone=el.cloneNode(true),originals=[el,...el.querySelectorAll('*')],copies=[clone,...clone.querySelectorAll('*')];
    copies.forEach((copy,index)=>{const style=getComputedStyle(originals[index]);for(const prop of ['fill','stroke','stroke-width','stroke-linecap','stroke-linejoin','opacity']){const value=style.getPropertyValue(prop);if(value)copy.setAttribute(prop,value);}copy.removeAttribute('class');copy.removeAttribute('style');});
    clone.setAttribute('xmlns','http://www.w3.org/2000/svg');
    return new XMLSerializer().serializeToString(clone);
  }
  function emitText(value,r,style,name){
    if(!value.trim())return;
    const size=parseFloat(style.fontSize),line=parseFloat(style.lineHeight)||size*1.5;
    measuring.font=`${style.fontWeight} ${size}px TroikaGolos`;
    const metrics=measuring.measureText(value);
    const ascent=metrics.fontBoundingBoxAscent||size*.9;
    const descent=metrics.fontBoundingBoxDescent||size*.25;
    const baseline=r.y-base.y+(r.height-ascent-descent)/2+ascent;
    push({kind:'text',...pos(r),text:value,name:name||value.slice(0,60),fontSize:size,fontWeight:+style.fontWeight||400,lineHeight:line,color:rgba(style.color),baseline});
  }
  function visit(el){
    if(!visible(el))return;
    const r=el.getBoundingClientRect(),s=getComputedStyle(el);
    const name=el.getAttribute('aria-label')||el.getAttribute('data-go')||el.getAttribute('data-page')||el.tagName.toLowerCase();
    if(el.tagName.toLowerCase()==='svg'){push({kind:'svg',...pos(r),svg:svgSource(el),name:'Иконка · '+(el.getAttribute('data-lucide')||name)});return;}
    if(el.tagName==='IMG'){
      const src=el.getAttribute('src')||'';
      if(src.startsWith('data:image/svg+xml;base64,')){
        const svg=new TextDecoder().decode(Uint8Array.from(atob(src.split(',')[1]),c=>c.charCodeAt(0)));
        push({kind:'svg',...pos(r),svg,name:'Фирменный логотип'});
      }
      return;
    }
    if(el.tagName==='CANVAS'){push({kind:'orb',...pos(r),state:el.closest('button').dataset.voice==='listening'||el.closest('button').dataset.listening==='true'?'listening':'idle',name:'Янтарный голосовой контур'});return;}
    const fill=rgba(s.backgroundColor);
    const allBorders=['Top','Right','Bottom','Left'].map(side=>({width:parseFloat(s['border'+side+'Width']),color:rgba(s['border'+side+'Color'])}));
    const uniform=allBorders.every(b=>b.width===allBorders[0].width&&JSON.stringify(b.color)===JSON.stringify(allBorders[0].color));
    const radius=parseFloat(s.borderTopLeftRadius)||0;
    if(fill&&fill.a>0||uniform&&allBorders[0].width>0){push({kind:'rect',...pos(r),radius,name:'Поверхность · '+name,fill,stroke:uniform?allBorders[0].color:null,strokeWidth:uniform?allBorders[0].width:0});}
    if(!uniform)allBorders.forEach((b,n)=>{if(b.width>0&&b.color&&b.color.a){let q=pos(r);if(n===0)q.h=b.width;if(n===1){q.x+=q.w-b.width;q.w=b.width;}if(n===2){q.y+=q.h-b.width;q.h=b.width;}if(n===3)q.w=b.width;push({kind:'rect',...q,radius:0,name:'Разделитель',fill:b.color});}});
    if(el.matches('input[type="checkbox"]')){push({kind:'checkbox',...pos(r),checked:el.checked,name:el.getAttribute('aria-label')||'Переключатель',accent:rgba(getComputedStyle(root).getPropertyValue(root.id==='troika-phone'?'--tk-accent':'--td-accent'))});return;}
    if(el.matches('input,textarea,select')){
      const value=el.tagName==='SELECT'?el.options[el.selectedIndex]?.text:(el.value||el.getAttribute('placeholder')||'');
      const left=r.x+parseFloat(s.paddingLeft)+parseFloat(s.borderLeftWidth),top=r.y+parseFloat(s.paddingTop)+parseFloat(s.borderTopWidth);
      const width=r.width-parseFloat(s.paddingLeft)-parseFloat(s.paddingRight)-2;
      const size=parseFloat(s.fontSize),line=parseFloat(s.lineHeight)||size*1.5;
      measuring.font=`${s.fontWeight} ${size}px TroikaGolos`;
      let rows=[],current='';
      for(const word of value.split(' ')){if(current&&measuring.measureText(current+' '+word).width>width){rows.push(current);current=word;}else current+=(current?' ':'')+word;}if(current)rows.push(current);
      rows.forEach((text,index)=>emitText(text,{x:left,y:top+index*line,width:Math.min(width,measuring.measureText(text).width),height:line},s,'Поле · '+text));
      return;
    }
    for(const child of el.childNodes){
      if(child.nodeType===Node.ELEMENT_NODE){visit(child);continue;}
      if(child.nodeType!==Node.TEXT_NODE||!child.textContent.trim())continue;
      const value=child.textContent;const rows=[];let current=null;
      for(let index=0;index<value.length;index++){
        const range=document.createRange();range.setStart(child,index);range.setEnd(child,index+1);const box=range.getBoundingClientRect();
        if(!box.width&&!box.height)continue;
        if(!current||Math.abs(box.y-current.y)>1){current={text:'',x:box.x,y:box.y,width:0,height:box.height};rows.push(current);}
        current.text+=value[index];current.width=Math.max(current.width,box.right-current.x);current.height=Math.max(current.height,box.height);
      }
      rows.forEach(row=>emitText(row.text,row,s));
    }
  }
  visit(root);
  return {width:base.width,height:base.height,nodes};
}

function rgbaCss(c){return c?`rgba(${round(c.r*255)},${round(c.g*255)},${round(c.b*255)},${round(c.a===undefined?1:c.a)})`:'none';}
function vectorMarkup(nodes,unique){
  return nodes.map((n,index)=>{
    const label=`id="${unique}-${n.id||index}" data-name="${escape(n.name||n.kind)}"`;
    if(n.kind==='rect')return `<rect ${label} x="${round(n.x)}" y="${round(n.y)}" width="${round(n.w)}" height="${round(n.h)}" rx="${round(Math.min(n.radius||0,n.w/2,n.h/2))}" fill="${rgbaCss(n.fill)}" stroke="${n.strokeWidth?rgbaCss(n.stroke):'none'}" stroke-width="${n.strokeWidth||0}"/>`;
    if(n.kind==='text')return `<text ${label} x="${round(n.x)}" y="${round(n.baseline)}" font-family="Golos Text,Arial,sans-serif" font-size="${n.fontSize}" font-weight="${n.fontWeight}" fill="${rgbaCss(n.color)}">${escape(n.text)}</text>`;
    if(n.kind==='checkbox'){const size=Math.min(n.w,n.h),color=n.checked?'#F5A623':'none';return `<g ${label}><rect x="${round(n.x)}" y="${round(n.y)}" width="${size}" height="${size}" rx="4" fill="${color}" stroke="${n.checked?'#F5A623':'#8C887F'}"/>${n.checked?`<path d="M${n.x+size*.22} ${n.y+size*.5} L${n.x+size*.43} ${n.y+size*.72} L${n.x+size*.8} ${n.y+size*.28}" fill="none" stroke="#0C0B0A" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>`:''}</g>`;}
    let svg=n.kind==='orb'?contourSvg(n.w,n.state,unique+'-'+index):n.svg;
    svg=svg.replace(/<svg\b/,`<svg x="${round(n.x)}" y="${round(n.y)}"`).replace(/width="[^"]+"/,`width="${round(n.w)}"`).replace(/height="[^"]+"/,`height="${round(n.h)}"`);
    return `<g ${label}>${svg}</g>`;
  }).join('\n');
}
function writeSvg(scene,target){const markup=`<svg xmlns="${F}" width="${round(scene.width)}" height="${round(scene.height)}" viewBox="0 0 ${round(scene.width)} ${round(scene.height)}" role="img" aria-label="${escape(scene.name)}"><title>${escape(scene.name)}</title>\n${vectorMarkup(scene.nodes,scene.id)}\n</svg>`;fs.writeFileSync(target,markup);}

module.exports={contourSvg,vectorMarkup,writeSvg};
if(require.main===module)(async()=>{
  for(const p of ['svg/android/dark','svg/android/light','svg/desktop/dark','svg/desktop/light','previews/android/dark','previews/android/light','previews/desktop/dark','previews/desktop/light','figma','source','components'])fs.mkdirSync(path.join(ROOT,p),{recursive:true});
  const browser=await chromium.launch({executablePath:process.env.TROIKA_BROWSER||'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe',headless:true});
  const scenes=requested&&fs.existsSync(path.join(ROOT,'figma/scenes.json'))?JSON.parse(fs.readFileSync(path.join(ROOT,'figma/scenes.json'),'utf8')).filter(s=>s.platform!=='components'):[];
  const errors=[],overflow=[];
  const upsert=scene=>{const index=scenes.findIndex(s=>s.id===scene.id);if(index>=0)scenes[index]=scene;else scenes.push(scene);};
  try{
    for(const platform of ['android','desktop']){
      const page=await browser.newPage({viewport:{width:platform==='android'?420:1060,height:1800},deviceScaleFactor:1});
      page.on('pageerror',e=>errors.push(String(e)));
      await page.goto('file:///'+path.join(ROOT,'prototype',platform+'.html').replace(/\\/g,'/'),{waitUntil:'domcontentloaded'});
      const frame=page.frameLocator('iframe'),selector=platform==='android'?'#troika-phone':'#troika-desktop';
      await frame.locator(selector).waitFor();
      await frame.locator('body').evaluate(async()=>{for(let n=0;n<120&&(!globalThis.lucide||typeof lucide.createIcons!=='function');n++)await new Promise(resolve=>setTimeout(resolve,100));if(!globalThis.lucide)throw Error('Bundled icon runtime did not load');await document.fonts.ready;});
      const names=await frame.locator(selector).evaluate(root=>root.troikaDesign.screens);
      const allNames=order.filter(name=>names.includes(name));
      for(const theme of ['dark','light']){
        for(const [index,name] of allNames.entries()){
          if(requested&&!requested.has(name))continue;
          await frame.locator(selector).evaluate((root,{name,theme})=>{root.troikaDesign.go(name);root.troikaDesign.theme(theme);if(globalThis.lucide)lucide.createIcons({attrs:{width:root.id==='troika-phone'?20:18,height:root.id==='troika-phone'?20:18}});},{name,theme});
          await frame.locator(selector).evaluate(root=>new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve))));
          const o=await frame.locator(selector).evaluate(root=>{const r=root.getBoundingClientRect();return [...root.querySelectorAll('*')].filter(el=>{const b=el.getBoundingClientRect();return b.width>0&&(b.right>r.right+1||b.left<r.left-1);}).map(el=>el.tagName+':'+(el.className?.baseVal||el.className));});
          if(o.length)overflow.push({platform,theme,name,elements:o.slice(0,6)});
          const scene=await frame.locator(selector).evaluate(extract);
          Object.assign(scene,{id:platform+'-'+theme+'-'+name,name:titles[name]||name,screen:name,platform,theme});
          for(let n=0;n<scene.nodes.length;n++){const node=scene.nodes[n];if(node.kind==='orb'){node.kind='svg';node.svg=contourSvg(node.w,node.state,scene.id+'-voice-'+n);}}
          const file=String(index+1).padStart(2,'0')+'-'+name;
          scene.svg=`svg/${platform}/${theme}/${file}.svg`;scene.preview=`previews/${platform}/${theme}/${file}.png`;
          writeSvg(scene,path.join(ROOT,scene.svg));
          await frame.locator(selector).screenshot({path:path.join(ROOT,scene.preview),animations:'disabled'});
          upsert(scene);
          if((index+1)%10===0)console.log(platform,theme,index+1,'/',allNames.length);
        }
        if(platform==='desktop'&&(!requested||requested.has('compact'))){
          await frame.locator(selector).evaluate((root,theme)=>{root.troikaDesign.compact();root.troikaDesign.theme(theme);lucide.createIcons({attrs:{width:18,height:18}});},theme);
          await frame.locator(selector).evaluate(root=>new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve))));
          const scene=await frame.locator(selector).evaluate(extract);Object.assign(scene,{id:platform+'-'+theme+'-compact',name:titles.compact,screen:'compact',platform,theme,svg:`svg/desktop/${theme}/37-compact.svg`,preview:`previews/desktop/${theme}/37-compact.png`});
          scene.nodes.forEach((n,index)=>{if(n.kind==='orb'){n.kind='svg';n.svg=contourSvg(n.w,n.state,scene.id+'-'+index);}});
          writeSvg(scene,path.join(ROOT,scene.svg));await frame.locator(selector).screenshot({path:path.join(ROOT,scene.preview)});upsert(scene);
        }
      }
      await page.close();
    }
  }finally{await browser.close();}
  fs.writeFileSync(path.join(ROOT,'figma','scenes.json'),JSON.stringify(scenes));
  fs.writeFileSync(path.join(ROOT,'manifest.json'),JSON.stringify({title:'Тройка · интерфейс Android и Windows',date:'2026-10-15',screens:scenes.map(({id,name,screen,platform,theme,width,height,svg,preview})=>({id,name,screen,platform,theme,width,height,svg,preview})),validation:{javascriptErrors:errors,overflow}},null,2));
  console.log(JSON.stringify({screens:scenes.length,layers:scenes.reduce((n,s)=>n+s.nodes.length,0),errors,overflow},null,2));
  if(errors.length||overflow.length)process.exitCode=1;
})();
